package lk.ijse.bookWormLibraryManagementSystem.service;

public interface SuperService {
}
