package lk.ijse.bookWormLibraryManagementSystem.repository;

public interface SuperRepository {}
